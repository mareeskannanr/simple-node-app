let express = require('express');
let router = express.Router();
let controller = require('./controller');

router.route('/books')
      .get(controller.getAllBooks)
      .post(controller.saveBook)
      .delete(controller.deleteAllBooks);

router.route('/book/:id')
      .get(controller.getBookById)
      .put(controller.updateBook)
      .delete(controller.deleteBook);      

module.exports = router;