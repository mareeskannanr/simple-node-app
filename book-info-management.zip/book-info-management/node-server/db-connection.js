let mongoose = require('mongoose');
const DB_URL = 'mongodb://localhost:27017/books';
let mongoDB = process.env.MONGODB_URI || DB_URL;
mongoose.connect(mongoDB);
mongoose.Promise = Promise;  
let db = mongoose.connection;
db.on('error', console.error.bind(console, 'MongoDB connection error: '));
db.once('open', () => console.log("MongoDB connection opened successfully!"));
module.exports = db;