let mongoose = require('mongoose');
let Schema = mongoose.Schema;

let bookSchema = new Schema({
    name: {
        unique: true,
        type: String,
        required: true,
        trim: true,
        sparse: true
    },
    description: {
        type: String,
        trim: true,
        sparse: true
    },
    authors: {
        type: [{
            type: Schema.Types.String,
            trim: true,
            sparse: true
          }],
        validate: [
            {validator: array => array.length > 0,  msg: 'Atleast one author name is required'},
            {validator: array => array.length == new Set(array).size,  msg: "Author's name must be unique"}
        ]
    },
    yearOfpublish: {
        type: Number,
        min: [1700, 'Year Of Publish value must between 1700 and 2040'],
        maximum: [2040, 'Year Of Publish value must between 1700 and 2040'],
        exclusiveMaximum: false
    },
    price: {
        type: Number,
        min: [1, 'Price must be greater than zero.']
    }
});

module.exports = mongoose.model('Book', bookSchema);